import pandas as pd
import sqlite3 as sql
import os
import struct
from array import array
import sys
import numpy as np
from sklearn import model_selection


# Dataloader class
class DataLoader(object):
    def __init__(self, path='.'):
        self.path = "/home/anurag/Desktop/IIITD/OOPD/dataset/"

        self.test_img_path = self.path + 't10k-images-idx3-ubyte'
        self.test_lbl_path = self.path + 't10k-labels-idx1-ubyte'

        self.train_img_path = self.path + 'train-images-idx3-ubyte'
        self.train_lbl_path = self.path + 'train-labels-idx1-ubyte'

        self.test_images = []
        self.test_labels = []

        self.train_images = []
        self.train_labels = []

    def load_testing(self):
        ims, labels = self.load(self.test_img_path, self.test_lbl_path)

        self.test_images = ims
        self.test_labels = labels

        return ims, labels

    def load_training(self):
        ims, labels = self.load(self.train_img_path, self.train_lbl_path)

        self.train_images = ims
        self.train_labels = labels

        return ims, labels

    @classmethod
    def load(cls, path_img, path_lbl):
        with open(path_lbl, 'rb') as file:
            magic, size = struct.unpack(">II", file.read(8))
            if magic != 2049:
                raise ValueError('We got an incorrect Magic Number,''got {}'.format(magic))

            labels = array("B", file.read())

        with open(path_img, 'rb') as file:
            magic, size, rows, cols = struct.unpack(">IIII", file.read(16))
            if magic != 2051:
                raise ValueError('We got an incorrect Magic Number,''got {}'.format(magic))

            image_data = array("B", file.read())

        images = []
        for i in range(size):
            images.append([0] * rows * cols)

        for i in range(size):
            images[i][:] = image_data[i * rows * cols:(i + 1) * rows * cols]

        return images, labels



if __name__=="__main__":
        data = DataLoader()
        print('\nLoading DataSet Done!')

        img_train, labels_train = data.load_training()
        train_img = np.array(img_train)
        train_labels = np.array(labels_train)
        print('\nTraining Data has been Loaded!')

        img_test, labels_test = data.load_testing()
        test_img = np.array(img_test)
        test_labels = np.array(labels_test)
        print('\nTesting Data has been Loaded!')

        # Features
        X = train_img

        # Labels
        y = train_labels

        X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.1)
        print('\nDataSet has been split into train and Validation set! 10% of data will be used as Validation Set')