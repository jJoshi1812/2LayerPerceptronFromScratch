import cProfile
import CodeFile
import Loading_Data
import numpy as np
from sklearn import model_selection
import pandas as pd
import pstats
from functools import wraps


# boilerplate for profiling
def profile(output_file=None, sort_by='cumulative', lines_to_print=None, strip_dirs=False):
    """
    Args:
        output_file: str or None. Default is None
            Path of the output file. If only name of the file is given, it's
            saved in the current directory.
            If it's None, the name of the decorated function is used.
        sort_by: str or SortKey enum or tuple/list of str/SortKey enum
            Sorting criteria for the Stats object.
            For a list of valid string and SortKey refer to:
            https://docs.python.org/3/library/profile.html#pstats.Stats.sort_stats
        lines_to_print: int or None
            Number of lines to print. Default (None) is for all the lines.
            This is useful in reducing the size of the printout, especially
            that sorting by 'cumulative', the time consuming operations
            are printed toward the top of the file.
        strip_dirs: bool
            Whether to remove the leading path info from file names.
            This is also useful in reducing the size of the printout
    Returns:
        Profile of the decorated function
    """

    def inner(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            _output_file = output_file or func.__name__ + '.prof'
            pr = cProfile.Profile()
            pr.enable()
            retval = func(*args, **kwargs)
            pr.disable()
            pr.dump_stats(_output_file)

            with open(_output_file, 'w') as f:
                ps = pstats.Stats(pr, stream=f)
                if strip_dirs:
                    ps.strip_dirs()
                if isinstance(sort_by, (tuple, list)):
                    ps.sort_stats(*sort_by)
                else:
                    ps.sort_stats(sort_by)
                ps.print_stats(lines_to_print)
            return retval
        return wrapper
    return inner

@profile(output_file='Profiling_Info.txt', sort_by='cumulative', strip_dirs=True)
def profiling_info(X, y):
    model = CodeFile.TLP(0.001)
    model = model
    model.add(CodeFile.LayerRelu(5))
    model.add(CodeFile.LayerSigmoid(10))
    model.fit(X, y)
    model.compile(epochs=1)


if __name__=="__main__":

    print("Loading the dataset and getting X (i.e features) and y (i.e target)")
    data = Loading_Data.DataLoader()
    print('Loading DataSet Done!')

    img_train, labels_train = data.load_training()
    train_img = np.array(img_train)
    train_labels = np.array(labels_train)
    print('Training Data has been Loaded!')

    # Features
    X = train_img

    # Labels
    y = train_labels

    X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.1)
    print('DataSet has been split into train and Validation set! 10% of data will be used as Validation Set')

    y = pd.Series(y_train)
    y = pd.get_dummies(y)
    y = y.values.T

    X = X_train.T

    profiling_info(X, y)

