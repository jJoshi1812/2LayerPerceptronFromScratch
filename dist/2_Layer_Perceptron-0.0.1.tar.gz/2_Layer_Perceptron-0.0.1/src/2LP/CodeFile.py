import numpy as np
# from keras.datasets import mnist
import pandas as pd
from sklearn import model_selection

import Loading_Data

class TLP:
    def __init__(self, alpha, opt=None):
        self.alpha = alpha
        self.opt = opt
        self.layers = []

    def fit(self, x, y):
        self.inpt = x
        self.y = y

    def add(self, layer):
        self.layers.append(layer)

    def compile(self, epochs=10):
        dims = self.inpt.shape[0]
        for i in range(len(self.layers)):
            self.layers[i].initializeLayer(dims)
            dims = self.layers[i].getNodes()
        print('Initialization of layers completed.')
        self.gradientDescent(epochs)

    def forwardPropagation(self, inpt):
        layers = self.layers
        for i in range(len(layers)):
            layer = layers[i]
            inpt = layer.forwardStep(inpt)
            # print('a{0} ='.format(i+1), inpt)
        return inpt

    def backwardPropagation(self, derivativeA):
        layers = self.layers
        for i in range(len(layers) - 1, -1, -1):
            layer = layers[i]
            # print('da{0} ='.format(i+1), derivativeA)
            derivativeA = layer.backStep(derivativeA, self.alpha)

    def gradientDescent(self, epochs):
        for i in range(epochs):
            for j in range(self.inpt.shape[1]):
                inpt = self.inpt[:, j].reshape(-1, 1)
                a = self.forwardPropagation(inpt)
                y_cap = self.y[:, j].reshape(-1, 1)
                lossDerivative = 2 * np.subtract(a, y_cap)
                self.backwardPropagation(lossDerivative)
            # print(self.layers[0].derivativeZ)
            # print(self.layers[1].derivativeZ)
            print('Epoch ', i + 1, ' COMPLETED')

    def predict(self, X_test):
        pred = []
        for i in range(X_test.shape[1]):
            inpt = X_test[:, i].reshape(-1, 1)
            a = self.forwardPropagation(inpt)
            pred.append(np.argmax(a))
        return pred


class Layers:
    def __init__(self, n):
        self.n = n
        self.weights = None
        self.bias = None

    def initializeLayer(self, inputdims):
        np.random.seed(35)
        self.weights = np.random.rand(self.n, inputdims) * 10 ** (-9)
        self.bias = np.zeros((self.n, 1))

    def getNodes(self):
        return self.n

    def backStep(self, derivativeA, learningRate):
        z = self.z.copy()
        a = self.inpt.copy()
        weights = self.weights.copy()
        # print('Weights before update =',self.weights)
        # print('z =',z)
        # print('Aprev =', a)
        # print('g\'(z) =',self.derivativeActivation(z))
        derivativeZ = np.multiply(self.derivativeActivation(z), derivativeA).copy()
        derivativeWeights = (derivativeZ @ a.T).copy()
        derivativeBias = derivativeZ.copy()
        derivativeAprev = (weights.T @ derivativeZ).copy()
        # print('derivativeZ =',derivativeZ)
        # print('derivativeWeights =',derivativeWeights)
        # print('derivativeAprev =',derivativeAprev)
        # Update weights and bias

        self.weights = np.subtract(self.weights, learningRate * derivativeWeights).copy()
        # print('Weights after update =',self.weights)
        self.bias = np.subtract(self.bias, learningRate * derivativeBias).copy()
        return derivativeAprev

    def forwardStep(self, inpt):
        self.inpt = inpt.copy()
        self.z = np.add((self.weights @ self.inpt), self.bias).copy()
        # print('Aprev =',inpt)
        # print('z =',self.z)
        a = self.activation(self.z).copy()
        return a


class LayerRelu(Layers):
    def __init__(self, n):
        super().__init__(n)

    def activation(self, Z):
        return (np.maximum(0, Z))

    def derivativeActivation(self, Z):
        R = self.activation(Z)
        # print(Z)
        return np.where(R > 0, 1, 0)


class LayerSigmoid(Layers):
    def __init__(self, n):
        super().__init__(n)

    def activation(self, z):
        return 1 / (1 + np.exp(-z))

    def derivativeActivation(self, z):
        s = self.activation(z)
        return s * (1 - s)


if __name__=="__main__":
    # (dataset_x_tr, dataset_y_tr), (dataset_x_ts, dataset_y_ts) = mnist.load_data()

    data = Loading_Data.DataLoader()
    print('\nLoading DataSet Done!')

    img_train, labels_train = data.load_training()
    train_img = np.array(img_train)
    train_labels = np.array(labels_train)
    print('\nTraining Data has been Loaded!')

    img_test, labels_test = data.load_testing()
    test_img = np.array(img_test)
    test_labels = np.array(labels_test)
    print('\nTesting Data has been Loaded!')

    # Features
    X = train_img

    # Labels
    y = train_labels

    X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.1)
    print('\nDataSet has been split into train and Validation set! 10% of data will be used as Validation Set')

    print(X_train.shape)
    print(y_train.shape)


    # y = pd.Series(dataset_y_tr)
    '''
    y = pd.get_dummies(y)
    y = y.values.T'''

    y = pd.Series(y_train)
    y = pd.get_dummies(y)
    y = y.values.T

    '''
    X = dataset_x_tr.reshape(60000, 784).T
    '''
    X = X_train.T


    model = TLP(0.001)
    model.add(LayerRelu(5))
    model.add(LayerSigmoid(10))
    model.fit(X, y)
    model.compile(epochs=1)

    # X_test = dataset_x_ts.reshape(-1, 784).T
    X_test = X_test.reshape(-1, 784).T
    y_pred = model.predict(X_test)

    # acc = np.sum(dataset_y_ts == y_pred) / len(y_pred)
    acc = np.sum(y_test == y_pred) / len(y_pred)

    print("accuracy is: ",acc)